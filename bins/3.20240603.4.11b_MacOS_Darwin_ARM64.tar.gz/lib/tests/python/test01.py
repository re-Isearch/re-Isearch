#!/usr/bin/python
#-------------------------------------------------
#ident  "%Z%%Y%%M%  %I% %G% %U% nonmonotonic"

import string
import sys
sys.path.append('/opt/nonmonotonic/lib/python%s.%s' % (sys.version_info[0:2]))
import IB


