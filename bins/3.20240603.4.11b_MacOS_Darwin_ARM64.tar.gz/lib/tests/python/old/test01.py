#!/usr/bin/python
#-------------------------------------------------
#ident  "%Z%%Y%%M%  %I% %G% %U% BSN"

import string
import sys
sys.path.append('/opt/BSN/lib/python%s.%s' % (sys.version_info[0:2]))
import IB


